# FinDocGPT RBI Compliance Agent

Ticket: RND-FIN-SLM-008

## Project Structure

* RBI Knowledge Base
* Rule-to-Clause Mapping Engine
* Annotated Compliance Dataset
* Compliance Scoring Framework
* Demo Script

## Requirements

Python 3.10+

## Run

python3 demo.py

## Output

The script generates:
sample_output_report.json

## Dataset Statistics

* 59 RBI regulations
* 210 regulation-to-clause mappings
* 120 annotated financial documents

## Compliance Features

* Missing clause detection
* Non-compliant language detection
* Compliance scoring
* Risk categorisation
* Remediation recommendations


