#!/usr/bin/env python3
"""
FinDocGPT RBI Compliance Agent — Demo Script
Ticket: RND-FIN-SLM-008
Version: 1.0

Usage:
    python3 demo.py [--input path/to/loan_agreement.txt] [--output report.json] [--doc-type "Loan Agreement"]

Description:
    Analyses a loan document against the RBI compliance knowledge base.
    Performs keyword + trigger phrase matching against 210 clause-level rules.
    Computes a weighted compliance score and generates a detailed JSON report.
"""

import json
import re
import sys
import os
import argparse
from datetime import datetime, timezone
from pathlib import Path

# ─────────────────────────────────────────────────────────────────
# PATHS (adjust if running from a different directory)
# ─────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent.resolve()

KB_PATH = SCRIPT_DIR / "rbi_knowledge_base.json"
MAPPINGS_PATH = SCRIPT_DIR / "rule_to_clause_mapping.json"
DEFAULT_INPUT = SCRIPT_DIR / "sample_loan_agreement.txt"
DEFAULT_OUTPUT = SCRIPT_DIR / "sample_output_report.json"

# ─────────────────────────────────────────────────────────────────
# SCORING CONFIG (from compliance_scoring_framework.json)
# ─────────────────────────────────────────────────────────────────
SEVERITY_WEIGHTS = {
    "Critical": 10,
    "High": 5,
    "Medium": 2,
    "Low": 1,
}

THRESHOLDS = [
    (85, 100, "Compliant", "GREEN", "No immediate action required"),
    (60, 84,  "Partially Compliant", "AMBER", "Address flagged issues within 30 days"),
    (0,  59,  "Non-Compliant", "RED", "Immediate remediation required before deployment"),
]

# Category weights (30+25+20+15+10 = 100)
CATEGORY_WEIGHTS = {
    "Mandatory Disclosures":    0.30,
    "Consent and Privacy":      0.25,
    "Borrower Protections":     0.20,
    "Grievance and Escalation": 0.15,
    "KYC and AML":              0.10,
}

# Map KB categories → scoring categories
CATEGORY_MAP = {
    "Digital Lending":       "Mandatory Disclosures",
    "Key Fact Statement":    "Mandatory Disclosures",
    "General":               "Mandatory Disclosures",
    "Fair Practice Code":    "Borrower Protections",
    "Data Privacy":          "Consent and Privacy",
    "Consent Management":    "Consent and Privacy",
    "KYC":                   "KYC and AML",
    "AML":                   "KYC and AML",
    "NBFC":                  "Mandatory Disclosures",
    "Credit Card":           "Mandatory Disclosures",
    "Outsourcing":           "Mandatory Disclosures",
    "Recovery and Penal":    "Borrower Protections",
    "Account Aggregator":    "Consent and Privacy",
    "Credit Bureau":         "Mandatory Disclosures",
    "Security":              "Borrower Protections",
    "Microfinance":          "Borrower Protections",
    "Payment Aggregator":    "Mandatory Disclosures",
    "Grievance":             "Grievance and Escalation",
}


# ─────────────────────────────────────────────────────────────────
# LOAD RESOURCES
# ─────────────────────────────────────────────────────────────────

def load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_document(path: Path) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


# ─────────────────────────────────────────────────────────────────
# ANALYSIS ENGINE
# ─────────────────────────────────────────────────────────────────

def normalise(text: str) -> str:
    """Lowercase and collapse whitespace for matching."""
    return re.sub(r"\s+", " ", text.lower().strip())


def keyword_score(doc_norm: str, keywords: list) -> float:
    """Return fraction of keywords found in the document."""
    if not keywords:
        return 0.0
    hits = sum(1 for kw in keywords if normalise(kw) in doc_norm)
    return hits / len(keywords)


def trigger_score(doc_norm: str, triggers: list) -> float:
    """Return fraction of trigger phrases found in the document."""
    if not triggers:
        return 0.0
    hits = sum(1 for tp in triggers if normalise(tp) in doc_norm)
    return hits / len(triggers)


def classify_check(kw_score: float, trig_score: float, mapping: dict) -> dict:
    """
    Classify each mapping rule as PASS, FAIL, or NEEDS_REVIEW.

    Heuristics:
    - PASS:        keyword score ≥ 0.60 AND (trigger score ≥ 0.50 OR no triggers)
    - FAIL:        keyword score < 0.25 (core terms completely absent)
    - NEEDS_REVIEW: everything else (partial match — potential paraphrasing)
    """
    if kw_score >= 0.60 and (trig_score >= 0.50 or not mapping.get("trigger_phrases")):
        status = "PASS"
        confidence = round(min(0.95, 0.70 + kw_score * 0.20 + trig_score * 0.10), 2)
    elif kw_score < 0.25:
        status = "FAIL"
        confidence = round(min(0.92, 0.80 + (0.25 - kw_score) * 0.40), 2)
    else:
        status = "NEEDS_REVIEW"
        confidence = round(0.50 + abs(kw_score - 0.40) * 0.30, 2)

    return {
        "status": status,
        "confidence": confidence,
        "keyword_match_rate": round(kw_score, 3),
        "trigger_match_rate": round(trig_score, 3),
    }


def get_scoring_category(kb_category: str) -> str:
    """Map a KB category to a scoring framework category."""
    return CATEGORY_MAP.get(kb_category, "Mandatory Disclosures")


def get_risk_level(score: float) -> dict:
    for lo, hi, label, color, action in THRESHOLDS:
        if lo <= score <= hi:
            return {"label": label, "color": color, "recommended_action": action}
    return {"label": "Non-Compliant", "color": "RED",
            "recommended_action": "Immediate remediation required"}


def compute_score(violations: list, total_checks: int) -> float:
    """
    Weighted deduction scoring.
    Score = 100 - (sum of severity weights for FAIL items / max possible deduction) * 100
    Max possible deduction = total_checks * weight_of_Critical (worst case all Critical)
    We use a gentler normalisation: deduct proportionally from 100.
    """
    if total_checks == 0:
        return 100.0

    total_deduction = sum(SEVERITY_WEIGHTS.get(v["severity"], 1) for v in violations)
    # Max deduction if every check were Critical
    max_possible = total_checks * SEVERITY_WEIGHTS["Critical"]
    score = max(0.0, 100.0 - (total_deduction / max_possible) * 100.0)
    return round(score, 1)


# ─────────────────────────────────────────────────────────────────
# MAIN ANALYSIS FUNCTION
# ─────────────────────────────────────────────────────────────────

def analyse_document(doc_text: str, mappings: list, doc_type: str = "Loan Agreement") -> dict:
    """
    Run all applicable mapping rules against the document.
    Returns structured results dict.
    """
    doc_norm = normalise(doc_text)
    doc_word_count = len(doc_text.split())

    results = {
        "passed": [],
        "failed": [],
        "needs_review": [],
    }

    applicable_mappings = [
        m for m in mappings
        if doc_type in m.get("applicable_doc_types", []) or not m.get("applicable_doc_types")
    ]

    for mapping in applicable_mappings:
        mid = mapping["mapping_id"]
        kws = mapping.get("keywords_to_search", [])
        tps = mapping.get("trigger_phrases", [])

        ks = keyword_score(doc_norm, kws)
        ts = trigger_score(doc_norm, tps)
        check = classify_check(ks, ts, mapping)

        entry = {
            "mapping_id": mid,
            "regulation_id": mapping.get("regulation_id"),
            "regulation_title": mapping.get("regulation_title"),
            "category": mapping.get("category"),
            "scoring_category": get_scoring_category(mapping.get("category", "")),
            "required_clause": mapping.get("required_clause"),
            "severity": mapping.get("severity"),
            "rbi_circular": mapping.get("rbi_circular"),
            "status": check["status"],
            "confidence": check["confidence"],
            "keyword_match_rate": check["keyword_match_rate"],
            "trigger_match_rate": check["trigger_match_rate"],
            "check_method": mapping.get("check_method"),
        }

        if check["status"] == "PASS":
            entry["compliant_outcome"] = mapping.get("compliant_outcome", "PASS")
            results["passed"].append(entry)
        elif check["status"] == "FAIL":
            entry["non_compliant_outcome"] = mapping.get("non_compliant_outcome", "FAIL")
            entry["remediation_guidance"] = mapping.get("remediation_guidance")
            results["failed"].append(entry)
        else:
            entry["remediation_guidance"] = mapping.get("remediation_guidance")
            entry["note"] = "Partial keyword match detected; recommend manual review by compliance officer."
            results["needs_review"].append(entry)

    return results, applicable_mappings


def build_category_breakdown(results: dict) -> dict:
    """Build per-scoring-category pass/fail/review counts and mini-score."""
    cats = {}
    for key, entries in results.items():
        for e in entries:
            sc = e.get("scoring_category", "Mandatory Disclosures")
            if sc not in cats:
                cats[sc] = {"passed": 0, "failed": 0, "needs_review": 0,
                            "critical_failures": 0, "high_failures": 0}
            cats[sc][key if key != "needs_review" else "needs_review"] += 1
            if key == "failed":
                if e.get("severity") == "Critical":
                    cats[sc]["critical_failures"] += 1
                elif e.get("severity") == "High":
                    cats[sc]["high_failures"] += 1
    return cats


# ─────────────────────────────────────────────────────────────────
# REPORT BUILDER
# ─────────────────────────────────────────────────────────────────

def build_report(doc_path: str, doc_type: str, results: dict,
                 applicable_mappings: list, kb_metadata: dict,
                 mapping_metadata: dict) -> dict:
    """Assemble the full compliance report JSON."""

    total_checks   = len(applicable_mappings)
    total_passed   = len(results["passed"])
    total_failed   = len(results["failed"])
    total_review   = len(results["needs_review"])

    # Compute score based only on definitive FAILs
    score = compute_score(results["failed"], total_checks)
    risk = get_risk_level(score)
    category_breakdown = build_category_breakdown(results)

    # Severity counts across failures
    severity_counts = {}
    for v in results["failed"]:
        sev = v.get("severity", "Unknown")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    # Top violations (Critical first, then High)
    priority_failures = sorted(
        results["failed"],
        key=lambda x: SEVERITY_WEIGHTS.get(x.get("severity", "Low"), 1),
        reverse=True
    )[:15]

    # Generate executive summary
    exec_summary = generate_executive_summary(
        doc_type, score, risk, total_checks, total_failed, total_review,
        severity_counts, category_breakdown
    )

    report = {
        "report_metadata": {
            "report_id": f"RPT-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "ticket": "RND-FIN-SLM-008",
            "system": "FinDocGPT Compliance Agent",
            "system_version": "1.0.0",
            "knowledge_base_version": kb_metadata.get("version", "1.0"),
            "mappings_version": mapping_metadata.get("version", "1.0"),
            "analysis_method": "keyword_and_trigger_phrase_matching",
            "document_analysed": str(doc_path),
            "document_type": doc_type,
        },
        "compliance_score": {
            "overall_score": score,
            "risk_level": risk["label"],
            "risk_color": risk["color"],
            "recommended_action": risk["recommended_action"],
            "score_interpretation": (
                f"Document scored {score}/100. "
                f"{total_failed} definitive violations detected across {total_checks} checks. "
                f"{total_review} checks require manual review."
            ),
        },
        "executive_summary": exec_summary,
        "check_summary": {
            "total_applicable_checks": total_checks,
            "passed": total_passed,
            "failed": total_failed,
            "needs_review": total_review,
            "pass_rate_pct": round(total_passed / total_checks * 100, 1) if total_checks else 0,
            "fail_rate_pct": round(total_failed / total_checks * 100, 1) if total_checks else 0,
        },
        "severity_breakdown": severity_counts,
        "category_breakdown": category_breakdown,
        "priority_violations": priority_failures,
        "all_violations": results["failed"],
        "needs_review": results["needs_review"],
        "compliant_clauses": results["passed"],
    }

    return report


def generate_executive_summary(doc_type, score, risk, total_checks, total_failed,
                                total_review, severity_counts, cat_breakdown) -> str:
    critical = severity_counts.get("Critical", 0)
    high = severity_counts.get("High", 0)
    medium = severity_counts.get("Medium", 0)

    lines = [
        f"This {doc_type} received an overall RBI compliance score of {score}/100, "
        f"placing it in the '{risk['label']}' category ({risk['color']} status). ",
    ]

    if critical > 0:
        lines.append(
            f"The document has {critical} CRITICAL violation(s) that must be remediated "
            f"immediately before this document can be executed with borrowers. "
        )
    if high > 0:
        lines.append(
            f"There are {high} HIGH-severity violation(s) that require attention within 7 days. "
        )
    if medium > 0:
        lines.append(
            f"{medium} MEDIUM-severity gap(s) were identified, addressable within 30 days. "
        )

    if total_review > 0:
        lines.append(
            f"{total_review} checks returned inconclusive results from keyword matching "
            f"and require manual review by a qualified compliance officer. "
        )

    # Identify worst category
    worst_cat = None
    worst_fails = 0
    for cat, data in cat_breakdown.items():
        if data["failed"] > worst_fails:
            worst_fails = data["failed"]
            worst_cat = cat

    if worst_cat and worst_fails > 0:
        lines.append(
            f"The '{worst_cat}' category has the highest number of gaps ({worst_fails} failures) "
            f"and should be prioritised in the remediation plan. "
        )

    lines.append(risk["recommended_action"] + ".")

    return "".join(lines)


# ─────────────────────────────────────────────────────────────────
# CLI ENTRYPOINT
# ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="FinDocGPT RBI Compliance Agent — Document Analyser"
    )
    parser.add_argument("--input", default=str(DEFAULT_INPUT),
                        help="Path to loan document text file")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT),
                        help="Path for output JSON report")
    parser.add_argument("--doc-type", default="Loan Agreement",
                        help="Document type (Loan Agreement, KFS, Sanction Letter, etc.)")
    args = parser.parse_args()

    print("=" * 60)
    print("  FinDocGPT RBI Compliance Agent  |  RND-FIN-SLM-008")
    print("=" * 60)

    # ── Load resources ──────────────────────────────────────────
    print(f"\n[1/5] Loading knowledge base from: {KB_PATH}")
    kb = load_json(KB_PATH)
    print(f"      Loaded {len(kb['regulations'])} regulations.")

    print(f"\n[2/5] Loading clause mappings from: {MAPPINGS_PATH}")
    mappings_data = load_json(MAPPINGS_PATH)
    mappings = mappings_data["mappings"]
    print(f"      Loaded {len(mappings)} clause-level rules.")

    print(f"\n[3/5] Loading document: {args.input}")
    doc_text = load_document(Path(args.input))
    word_count = len(doc_text.split())
    print(f"      Document length: {word_count:,} words.")

    # ── Run analysis ─────────────────────────────────────────────
    print(f"\n[4/5] Running compliance analysis (doc_type='{args.doc_type}')...")
    results, applicable = analyse_document(doc_text, mappings, args.doc_type)

    total = len(applicable)
    passed = len(results["passed"])
    failed = len(results["failed"])
    review = len(results["needs_review"])

    print(f"      Applicable rules:  {total}")
    print(f"      ✓ PASS:            {passed}")
    print(f"      ✗ FAIL:            {failed}")
    print(f"      ⚠ NEEDS REVIEW:    {review}")

    # ── Build report ─────────────────────────────────────────────
    print(f"\n[5/5] Building compliance report...")
    report = build_report(
        doc_path=args.input,
        doc_type=args.doc_type,
        results=results,
        applicable_mappings=applicable,
        kb_metadata=kb.get("metadata", {}),
        mapping_metadata=mappings_data.get("metadata", {}),
    )

    score = report["compliance_score"]["overall_score"]
    risk  = report["compliance_score"]["risk_level"]
    color = report["compliance_score"]["risk_color"]

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 60)
    print(f"  COMPLIANCE SCORE:  {score} / 100")
    print(f"  RISK LEVEL:        {risk} [{color}]")
    print(f"  ACTION:            {report['compliance_score']['recommended_action']}")
    print("=" * 60)
    print(f"\n  Report saved to: {args.output}")

    # Print top violations
    top_violations = report["priority_violations"][:5]
    if top_violations:
        print(f"\n  TOP {len(top_violations)} VIOLATIONS:")
        for i, v in enumerate(top_violations, 1):
            print(f"  {i}. [{v['severity']:8s}] {v['regulation_id']} — {v['required_clause']}")
            if v.get("remediation_guidance"):
                # Truncate for terminal display
                guidance = v["remediation_guidance"][:100] + "..." if len(v["remediation_guidance"]) > 100 else v["remediation_guidance"]
                print(f"             ↳ {guidance}")

    print("\n  Done.\n")
    return report


if __name__ == "__main__":
    main()
